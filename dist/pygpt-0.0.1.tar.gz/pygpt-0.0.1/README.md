# Installation
To project is a simple one to install. Go to the command prompt on Windows or terminal on Linux and run the command below

`pip install pygpt`

or

`python3 -m pip install pygpt`

Once the package is installed, enter your editor and import the package
`import pygpt`
or
`from pygpt import runAi`

Once imported, called the method

`pygpt.runAi()` if the first import was used
or
`runAi()` if the second import was used